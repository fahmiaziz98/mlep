# Prediction Pipeline Usage Guide
### Development Usage

1. **Batch Predictions:**
    - Execute batch predictions using the following command:
        ```shell
        python -m batch_prediction_pipeline.batch
        ```

2. **Monitor Predictions:**
    - Monitor predictions by running:
        ```shell
        python -m batch_prediction_pipeline.monitor
        ```
    